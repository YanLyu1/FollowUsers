/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.servlet;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Hardik
 */
public class AuthenticationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        String option = req.getParameter("option");
        String userName = req.getParameter("userName");
        String password = req.getParameter("password");
        String redirectPage = "index.html";

        java.sql.Connection connection = null;
        Statement stmt = null;
        // Load the driver and make cconnection

        if (option.equals("login")) {
            // Check if it is a valid user 
            
        } else {
            // Check if user exists then create and add user to session
            
            // Insert query string
            String sqlQuery = "";
            System.out.println("");
            
            try {
                int rs = stmt.executeUpdate(sqlQuery);    
                if (rs != 0) {
                    System.out.println(rs);
                    session.setAttribute("userName", userName);
                    redirectPage = "/Lab3/message";
                }
                
            } catch (SQLException ex) {
                System.out.println(ex);
            } finally {
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException ex) {
                    System.out.println("SQLException" + ex.getMessage());
                }
            }
        }
        resp.sendRedirect(redirectPage);
    }
}
