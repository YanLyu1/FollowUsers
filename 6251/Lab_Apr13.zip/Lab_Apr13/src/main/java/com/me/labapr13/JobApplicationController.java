package com.me.labapr13;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.me.pojo.Applicant;

@Controller
public class JobApplicationController {
	@Autowired
	private ServletContext application;   //only static global instances to be AutoWired
	
	@PostConstruct
	public void init() {
		// initialize global instances
	}

	@PreDestroy
	public void destroy() throws Exception {
		// do cleanup
	}

	@RequestMapping(value = "/job/apply.htm", method = RequestMethod.GET)
	public String showForm(HttpServletRequest request, ModelMap model, Applicant applicant) {
		//command object
		//model.addAttribute("applicant", applicant);
		request.setAttribute("action", "save");
		return "job-form";
	}
	
	@RequestMapping(value = "/job/apply.htm", method = RequestMethod.POST)
	public String handleUpload(@ModelAttribute("applicant") Applicant applicant) {
		return "job-success";
	}
}
