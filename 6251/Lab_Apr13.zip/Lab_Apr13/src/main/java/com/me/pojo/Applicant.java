package com.me.pojo;

import org.springframework.web.multipart.MultipartFile;

public class Applicant {
	private String first;
	private String last;
	private String email;
	private String nuid;
	private String gpa;
	private String major;
	private String entrance;
	private String graduation;
	private String aboutme;
	private String skills;
	private String coop;
	private String prevta;
	private String courses;
	private String whichclass;
	
	private MultipartFile photo;
	private MultipartFile resume;
	
	private String saveorupdate;
	private int authkey1;
	private int authkey2;
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNuid() {
		return nuid;
	}
	public void setNuid(String nuid) {
		this.nuid = nuid;
	}
	public String getGpa() {
		return gpa;
	}
	public void setGpa(String gpa) {
		this.gpa = gpa;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getEntrance() {
		return entrance;
	}
	public void setEntrance(String entrance) {
		this.entrance = entrance;
	}
	public String getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	public String getAboutme() {
		return aboutme;
	}
	public void setAboutme(String aboutme) {
		this.aboutme = aboutme;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getCoop() {
		return coop;
	}
	public void setCoop(String coop) {
		this.coop = coop;
	}
	public String getPrevta() {
		return prevta;
	}
	public void setPrevta(String prevta) {
		this.prevta = prevta;
	}
	public String getCourses() {
		return courses;
	}
	public void setCourses(String courses) {
		this.courses = courses;
	}
	public String getWhichclass() {
		return whichclass;
	}
	public void setWhichclass(String whichclass) {
		this.whichclass = whichclass;
	}
	public MultipartFile getPhoto() {
		return photo;
	}
	public void setPhoto(MultipartFile photo) {
		this.photo = photo;
	}
	public MultipartFile getResume() {
		return resume;
	}
	public void setResume(MultipartFile resume) {
		this.resume = resume;
	}
	public String getSaveorupdate() {
		return saveorupdate;
	}
	public void setSaveorupdate(String saveorupdate) {
		this.saveorupdate = saveorupdate;
	}
	public int getAuthkey1() {
		return authkey1;
	}
	public void setAuthkey1(int authkey1) {
		this.authkey1 = authkey1;
	}
	public int getAuthkey2() {
		return authkey2;
	}
	public void setAuthkey2(int authkey2) {
		this.authkey2 = authkey2;
	}
}
